<?php
$con =mysql_connect("localhost", "satyavan_jewel", "jewel123");
mysql_select_db("satyavan_jewel",$con);
?>