<?php
ini_set( "display_errors", 0);

include('config.php');


$mobile=$_POST['mobile'];
$name=$_POST['name'];
$amt=$_POST['amount'];
$paid_date=$_POST['paid_date'];


 mysql_query("insert into `commission_paid`(name,mobile,amount,paid_date) values('$name','$mobile','$amt',STR_TO_DATE('".$paid_date."','%d/%m/%Y'))");

header('location:../../../application/views/reports/commReport.php');



?>