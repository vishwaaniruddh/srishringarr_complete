<?php
	include('config.php');
	$agent=$_GET['agent'];
	
		$sql="SELECT * FROM `approval_detail` WHERE `bill_id` in (SELECT bill_id  FROM  `approval` WHERE  `cust_id` ='$agent')group by item_id";
		$result=mysql_query($sql);
	
		
	/*	
		$sql11="SELECT * FROM `phppos_people` where person_id='$row10[1]'";
		$result11=mysql_query($result11);
		$row11=mysql_fetch_row($result11);
		
		$sql12="SELECT * FROM `approval_detail` where bill_id='$row10[0]'";
		$result12=mysql_query($result12);
		$row12=mysql_fetch_row($result12);
		
		$sql13="SELECT * FROM `order_detail` where bill_id='$row10[0]'";
		$result13=mysql_query($result13);
		$row13=mysql_fetch_row($result13);
	
		$qry="SELECT * FROM `phppos_people` where first_name like ('".$id4."') order by first_name ASC";
	    $res=mysql_query($qry);                
        $num=mysql_num_rows($res);
		*/	
				 				 
?>
<table><tr><td width="947">
</td>
<td width="432"></td>
</tr>
<tr>
<td>
<table  border="1" cellpadding="4" cellspacing="0" width="946" align="left">
 <tr>
    <th width='83' height="34"><U>Item Code</U></th>
    <th width='140'><u>Item Category</u></th>
    <th width='90'><u>MRP</u></th>
    <th width='107'><U>Sales MRP</U></th>
    <th width='99'><u>Balance Qty</u></th>
    <th width='101'><U>Sold Qty</U></th>
	<th width="83"><U>Total Qty</U></th>
    <th width='186'><U>Total Sold Qty Amount</U></th>
  </tr>
<?php
$sum=0;
$sum1=0;
while($row = mysql_fetch_row($result)) 
 {
$sq="SELECT SUM( qty),SUM( amount ) FROM  `approval_detail` WHERE return_qty =0 and `item_id`='$row[1]' and bill_id='$row[0]'";
$res2 = mysql_query($sq);
$row1=mysql_fetch_row($res2);

$qry="SELECT * FROM  `phppos_items` where name ='$row[1]'";
$res2 = mysql_query($qry);
$row2=mysql_fetch_row($res2);
?>				   
				   
<tr>
<td width="83"><?php echo $row[1]; ?></td>
<td width="140" align="center"><?php echo $row2[1]; ?></td>
<td width="90"><?php echo "Rs.".$row2[5]; ?></td>
<td width="107"><?php echo "Rs.".$row2[6] ?></td>
<td width="99"><?php echo $row2[7]; ?></td>
 <td  align="left" width="101"><?php echo $row1[0]; ?></td>
 <?php
 $ttl=$row2[7]+$row1[0];
 ?>
 <td align="left"><?php echo $ttl; ?></td>
  <td  align="left" width="186"><?php echo "Rs.".$row1[1]; ?></td>
  </tr>	
			<?php 	$sum+=$row[5]*$row[7];
			$sum1+=$row[6]*$row[7];
			} ?>
            <tr><td colspan="2" align="right"><b>Total</b> </td><td><?php echo "Rs.".$sum; ?></td>
            <td><?php echo "Rs.".$sum1; ?></td><td colspan="4"></td></tr>
</table> 
</td>
<td></td></tr></table>