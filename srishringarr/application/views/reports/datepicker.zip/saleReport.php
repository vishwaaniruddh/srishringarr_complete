<?php
ini_set( "display_errors", 0);
$s=$_GET['submit'];

$id=$_GET['cid'];
$from=$_GET['from'];
$to=$_GET['to_date'];
$pd=0;
$sum=0;
?>
<script type="text/javascript" src="datepick_js.js"></script>
<link rel="stylesheet" type="text/css" href="date_css.css"  />
<script>
/////////////////

function validate1(form1){
 with(form1)
 {
  
if(cid.value== -1)
 {
alert("Please Select Customer Name to continue.");
cid.focus();
return false;
}

}
 return true;
 }


</script>
 
<div style="text-align: center;">
  <a href="../../../index.php/reports">Back</a>
  <table width="1096"  border="1" cellpadding="4" cellspacing="0" bgcolor="#FFFFFF"  align="center">
  
<tr>
<td align="center">

<img src="bill.png" width="408" height="165"/><br><br>
<b>Sales Report</b>

</td></tr>
<tr>
<td width="1084"  valign="top">
      
     <center>
       <form  action="saleReport.php" onSubmit="return validate1(this)">
       <br/>
       
       <table width="1073" height="42"><tr>
       <td width="293" height="36"><strong>From Date :</strong>
         <input type="text" name="from" id="from" onClick="displayDatePicker('from');" /></td>  
       <td width="269" ><strong>To Date: </strong>
         <input type="text" name="to_date" id="to_date" onClick="displayDatePicker('to_date');"/></td><td width="324" height="34">
         <strong>Customer Name:&nbsp;</strong>&nbsp;&nbsp;
         <select name="cid" id="cid">
           <option value="-1" >select</option>
           <?php 
	  include('config.php');
	  $result = mysql_query("SELECT * FROM  phppos_people order by first_name");
	  while($row = mysql_fetch_row($result)){ 
	  ?>
           <option value="<?php echo $row[11]; ?>" ><?php echo $row[0] ."  ". $row[1]; ?></option>
           <?php } ?>
         </select>
        </td><td width="167"> <input type="submit" value="Search" name="submit" /></td></tr></table>
       </form></center>
 </td></tr>
 
<tr><td height="103">
  <?php

if(isset($s)){
       
 // echo $from;
   if($from=="" && $to==""){
	  $qry="SELECT * FROM  `approval` where cust_id='$id' and status='S'";
		//echo "all";
   }else if($from==""){
	    $qry="SELECT * FROM  `approval` where cust_id='$id' and bill_date <=STR_TO_DATE('".$to."','%d/%m/%Y') and status='S'";
	
	 //  echo "to";
   }else if($to==""){
	// echo "SELECT * FROM  `approval` where cust_id='$id' and bill_date=STR_TO_DATE('".$from."','%d/%m/%Y') and status='A'";
	      $qry="SELECT * FROM  `approval` where cust_id='$id' and bill_date >=STR_TO_DATE('".$from."','%d/%m/%Y') and status='S'";
	
	   
   }else{
   $qry="SELECT * FROM  `approval` where cust_id='$id' and bill_date BETWEEN STR_TO_DATE('".$from."','%d/%m/%Y') and STR_TO_DATE('".$to."','%d/%m/%Y') and status='S'";
    // echo "between";
   }
$res=mysql_query($qry);                
$num=mysql_num_rows($res);
			
				 				 
?>
<table  border="1" cellpadding="4" cellspacing="0" width="1085" align="left">
 <tr>
 <th width='115' height="34"><U>Sr.No.</U></th>
    <th width='115' height="34"><U>Bill No.</U></th>
    <th width='183'><u>Customer Name</u></th>
    <th width='127'><U>Bill Date</U></th>
    <th width='165'><U>Paid Amount</U></th>
    <th width='251'><U>Balance Amount</U></th>
  
    <th width='165'><u>Bill Detail</u></th>
  </tr>
<?php
$i=1;
while($row = mysql_fetch_row($res)) 
 {
$sql1=mysql_query("SELECT * FROM `phppos_people` WHERE `person_id`='$row[1]'");
$row1=mysql_fetch_row($sql1);
 
 $qry2="SELECT sum(paid_amount) FROM  `approval` where bill_id ='$row[0]'";
$res2=mysql_query($qry2);                
$num2=mysql_num_rows($res2);
$row2=mysql_fetch_row($res2);
			
$qry3="SELECT sum(`amount`) FROM `approval_detail` WHERE bill_id ='$row[0]'";
$res3=mysql_query($qry3);
$row3=mysql_fetch_row($res3);
$s=$row3[0]-$row2[0];
//echo $row2[0]."&&".$s;
?>				   
				   
<tr>
<td width="115"><?php echo $i; ?></td>
<td width="115"><?php echo $row[0]; ?></td>
<td width="183" align="center"><?php echo $row1[0]." " .$row1[1]; ?></td>
<td width="127"> <?php if(isset($row[2]) and $row[2]!='0000-00-00') echo date('d/m/Y',strtotime($row[2])); ?></td>
<td width="165"><?php echo $row2[0]; $pd+=$row2[0]; ?></td>
<td width="251"><?php echo $s; $sum+=$s; ?></td>
 <td  align="center" width="165"><a href="sales_report_detail.php?id=<?php echo $row[0]; ?>" target="_new">Bill Detail</a></td>

     </tr>
				
			<?php $i++; } ?>
            <tr><td colspan="4" align="right"><b>Total :</b></td>
            <td><?php echo $pd; ?></td>
            <td colspan="2"><?php echo $sum; ?></td>
            </table>
            <?php } else { }?>
	</td></tr> </table>
</div>
<div align="center">You are using Point Of Sale Version 10.5 .</div>