<?php
include('config.php');

$it=$_GET['barcode'];
$bar=$_GET['barcode2'];
$cnt=$_GET['cnt'];
//echo $it."/".$bar;

       if($bar==""){
      // echo "1";
       $barcode=$_GET['barcode'];
       $qry="select item_number,name,category,unit_price from  phppos_items where name='$barcode' ";
       
}else if($it==""){
//echo "2";
 $barcode=$_GET['barcode2'];
 $qry="select item_number,name,category,unit_price from  phppos_items where item_number='$barcode'";
}
$res=mysql_query($qry);                
$num=mysql_num_rows($res);
						 				 
?>

<table border="0"  width="990" align="left">
<?php
$z=1;
while($suggest = mysql_fetch_array($res, MYSQL_ASSOC)) 
 {

$item_number =$suggest['item_number']; 
$name=$suggest['name']; 
$category=$suggest['category']; 
$unit_price=$suggest['unit_price'];
$a=($unit_price*30)/100;
$b=($a-$discount);
?>				   
				   
<tr>
<td width="97"><?php echo ++$cnt; ?></td>
<td width="97"><?php echo $name; ?><input name="design[]" type="hidden" value="<?php echo $name; ?>" class="design"/>
<input name="barc[]" type="hidden" value="<?php echo $item_number; ?>" class="barc"/>
</td>
<td width="184" ><?php echo $category; ?><br>
  <br><textarea name="items[]" id="items[]" rows="10" cols="15">Neck PC,Long Set, Earrings, Tikka, Damini, Hathful, Baju Bandh, Kamar Patta, Pag Panja, Payal, Nath</textarea></td>
<td width="57" align="left"> <?php echo $unit_price; ?></td>

<td width="80">

<table  border="0">
<?php 
$sql=mysql_query("SELECT * FROM `order_detail` where `item_id`='$barcode'");
while($row=mysql_fetch_row($sql)){
?>
<tr><td>(<?php echo $row[8]; ?>)</td></tr>
<?php  } ?>
</table>

</td>

<td  align="left" width="202"> <input name="qty[]" type="text" value="1" class="qty" style="width:100px;" onKeyUp="checkTotalqty();checkTotal1();checkTotal();"/></td>
<td  align="left" width="147"> <input name="prz[]" class="prz" id="prz1" type="text" style="width:100px;" value="<?php echo round($a, 0); ?>"  onKeyUp="checkTotalqty();checkTotal1();checkTotal();;"/></td>
<td width="139"><input type="text" name="discount[]" class="discount" id="prz2" style="width:100px;" onKeyUp="checkTotalqty();checkTotal1();checkTotal();" /></td>
<td width="137"><input type="text" class="amt"  name="amt[]" style="width:100px;"  onKeyUp="checkTotalqty();checkTotal1();checkTotal();"/></td>
<td width="115"> <input name="dep[]" type="text" style="width:100px;" class="txt" /></td> 
</tr>
				
			<?php  } ?>
            </table>
			  
               