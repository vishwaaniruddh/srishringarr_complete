<?php
include('config.php');

$it=$_GET['barcode'];
$bar=$_GET['barcode2'];
if($_GET['fromdate']!=""){
  $_fromdatearr = explode("/",$_GET['fromdate']);
  $fromdate= $_fromdatearr[2]."-".$_fromdatearr[1]."-".$_fromdatearr[0];
}
//$todate = $_GET['todate'];


if($_GET['todate']!=""){
    $_todatearr = explode("/",$_GET['todate']);
    $todate= $_todatearr[2]."-".$_todatearr[1]."-".$_todatearr[0];
}
//$todate=date('Y-m-d',strtotime($_GET['todate']));

//echo $it."/".$bar;
//echo $todate;

if($bar==""){
   // echo "1";
    $barcode=$_GET['barcode'];
 
//$num=mysql_num_rows($sql2);
//select `bill_id`,`pick_date`,`delivery_date` from `phppos_rent` where  `pick_date` >= now() AND `delivery_date` >= now() and bill_id in(select bill_id from `order_detail` where `item_id`='b1') 
       
}else if($it==""){
//echo "2";
 $barcode=$_GET['barcode2'];
 /* $qry="SELECT * FROM `order_detail` where `item_id`='$barcode' and bill_id in(SELECT bill_id  FROM `phppos_rent` WHERE `pick_date` >= now() AND `delivery_date` >= now() ORDER BY `phppos_rent`.`pick_date` ASC) group by bill_id"; */
}
if($barcode!=""){
    if($fromdate=="" && $todate==""){
 $qry="SELECT * FROM `order_detail` where `item_id`='$barcode' and bill_id in(SELECT bill_id  FROM `phppos_rent` WHERE `pick_date` >= now() AND `delivery_date` >= now() ORDER BY `phppos_rent`.`pick_date` ASC) group by bill_id";
    }else{
        $qry="SELECT * FROM `order_detail` where `item_id`='$barcode' and bill_id in(SELECT bill_id  FROM `phppos_rent` WHERE `pick_date` >= '$fromdate' AND `pick_date` <= '$todate' ORDER BY `phppos_rent`.`pick_date` ASC) group by bill_id";
    }
}else{
    if($fromdate!="" && $todate!=""){
 $qry="SELECT * FROM `order_detail` where bill_id in(SELECT bill_id  FROM `phppos_rent` WHERE `pick_date` >= '$fromdate' AND `pick_date` <= '$todate' ORDER BY `phppos_rent`.`pick_date` ASC) group by bill_id";
    }
}
//echo $qry;
$res=mysql_query($qry);                
$num=mysql_num_rows($res);
if($num>0){	
$i=1;					 				 
?>

<table border="1"  width="43%" align="center">
    <?php if($barcode!=""){?>
    <tr>
<td align="center" colspan="8"><?php echo "<b>Item Name : ".strtoupper($barcode)."</b>";?></td></tr>
<?php }?>
<tr>
<th width="61">Sr. No</th>
<?php if($barcode==""){?>
<th width="97">Item ID</th>
<?php }?>
<th width="97">Bill No.</th><th width="125">Customer Name</th><th width="160">Contact No.</th><th width="160">Description</th><th width="125">Pick Date</th><th width="193">Delivery Date</th><th width="160">Trail Date</th><th width="125">Measurement</th><th width="193">Is Delivery</th></tr>
<?php while($row=mysql_fetch_array($res)){
		$qryrent=mysql_query("Select pick_date, delivery_date,cust_id,trail_date,measurement,is_delivery from phppos_rent where bill_id='$row[0]'");
		$resrent=mysql_fetch_row($qryrent);
		
		$gtds=mysql_query("select * from phppos_people where person_id='".$resrent[2]."'");
		$gtdsfr=mysql_fetch_array($gtds);
		
		$bill=mysql_query("SELECT * FROM `order_detail` where bill_id='$row[0]'");
		?>
        <tr align="center"><td><?php echo $i;?></td>
        <?php if($barcode==""){?>
       <!-- <td><?php //echo $row[1];?></td>-->
        <td>
           <?php while($bill1 = mysql_fetch_array($bill)){
            $item=$bill1[1];
            $item1=mysql_query("SELECT * FROM `phppos_items` where name='$item'");
            $item2=mysql_fetch_row($item1);?>
            <?php echo $item2[0]."--".$bill1[9]."<br>"; } ?>
        </td>
        <?php }?>
        <td><?php echo $row[0];?></td>
        <td><?php echo $gtdsfr[0]." ".$gtdsfr[1];?></td>
        <td><?php echo $gtdsfr[2];?></td>
         <td><?php echo $row[7];?></td>
        <td><?php if($resrent[0]=='') { echo $resrent[0]; } else { echo date('d-m-Y',strtotime($resrent[0]));} ?></td>
        
        <td><?php if($resrent[1]=='0000-00-00') { echo $resrent[1];} else { echo date('d-m-Y',strtotime($resrent[1])); }?></td>
        
        <td><?php if($resrent[3]=='0000-00-00') { echo $resrent[3];} else{ echo  date('d-m-Y',strtotime($resrent[3]));} ?></td>
        
         <td><?php echo $resrent[4];?></td>
          <td><?php echo $resrent[5];?></td>
        </tr>
        <?php $i+=1;}?>
</table>
			  
               
		<?php }
		else
		echo "No Bookings"; ?>