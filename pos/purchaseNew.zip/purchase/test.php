<?php
include('items_showing_calculate.php');
update_items_showing(set10002);
?>