<?php
include("config.php");
$name=$_GET['qu'];

//echo "select username from login where 1";
$sql=mysqli_query($con,"select name from phppos_items where name='".$name."' ");
if(mysqli_num_rows($sql) > 0)
{
echo "taken";
}
else{echo "ok";};


?>