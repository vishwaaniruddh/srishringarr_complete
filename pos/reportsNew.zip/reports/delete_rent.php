<?php
ini_set( "display_errors", 0);

// include('config.php');
include('../db_connection.php') ;
$con=OpenSrishringarrCon();


$id=$_GET['id'];

 
  mysqli_query($con,"DELETE FROM `order_detail` WHERE `bill_id`='$id'");
   mysqli_query($con,"DELETE FROM `phppos_rent` WHERE `bill_id`='$id'");

header('location:../../../application/views/reports/rent_return.php');
CloseCon($con);


?>