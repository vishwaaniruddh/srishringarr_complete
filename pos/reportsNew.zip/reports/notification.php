<html>

<body>
    <form action="send_notification.php" method="post" enctype="multipart/form-data">
        <table>
            <tr>
                <td>Title:</td>
                <td>
                    <input type="text" name="title" /> </td>
            </tr>
            <tr>
                <td>Message:</td>
                <td>
                    <input type="text" name="message" /> </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="submit" /> </td>
            </tr>
        </table>
    </form>
</body>

</html>