<? include_once('site_header.php'); 

$userid=$_SESSION['gid'];

?>


	<style>
		.site-content {
    outline: none;
}

.site-content, .header-widget-region {
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
@media (max-width: 66.4989378333em) {
.col-full {
    margin-left: 2.617924em;
    margin-right: 2.617924em;
    padding: 0;
}

}


table {
    border-spacing: 0;
    width: 100%;
    border-collapse: separate;
}

@media (min-width: 768px){
    
    .woocommerce-MyAccount-content {
    width: 76.4705882353%;
    float: right;
    margin-right: 0;
}

table.my_account_orders {
    font-size: 0.875em;
}
table.shop_table_responsive thead {
    display: table-header-group;
}


.col-full {
    max-width: 66.4989378333em;
    margin-left: auto;
    margin-right: auto;
    padding: 0 2.617924em;
    box-sizing: content-box;
}

 .widget-area {
    margin-bottom: 2.617924em;
}

.content-area {
    width: 100%;
    float: left;
 
}

.woocommerce-MyAccount-navigation {
    width: 17.6470588235%;
    float: left;
    margin-right: 5.8823529412%;
}

.woocommerce-MyAccount-content {
    width: 76.4705882353%;
    float: right;
    margin-right: 0;
}

table.shop_table_responsive tr td {
    display: table-cell;
}

table.shop_table_responsive tbody tr td, table.shop_table_responsive tbody tr th {
    text-align: left;
}

}

table:not( .has-background ) th {
    background-color: #000000;
}

table thead th,td {
    padding: 1.41575em;
    vertical-align: middle;
}
table th, table tbody td, #payment .payment_methods li, #comments .comment-list .comment-content .comment-text, #payment .payment_methods > li .payment_box, #payment .place-order {
    background: #f8f8f8!important;
}
table th {
    font-weight: 600;
}



table thead th {
    padding: 1.41575em;
    vertical-align: middle;
}

p {
    margin: 0 0 1.41575em;
}	

.hentry .entry-content .woocommerce-MyAccount-navigation ul {
    margin-left: 0;
    border-top: 1px solid rgba(0, 0, 0, 0.05);
}

ul {
    list-style: disc;
}
ul, ol {
    margin: 0 0 1.41575em 3em;
    padding: 0;
}

.hentry .entry-content .woocommerce-MyAccount-navigation ul li {
    list-style: none;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    position: relative;
}
a {
    color: #227504;
        font-weight: 600;
}
.hentry .entry-content .woocommerce-MyAccount-navigation ul li.woocommerce-MyAccount-navigation-link a {
    text-decoration: none;
    padding: 0.875em 0;
    display: block;
}	
.site-main {
    margin-bottom: 2.617924em;
}

.hentry {
    /*border-bottom: 1px solid #ededed;*/
    margin: 0 0 4.235801032em;
}

article, aside, details, figcaption, figure, footer, header, hgroup, main, menu, nav, section, summary {
    display: block;
}
#content{
        margin: 3% auto;
}


	</style>





<div id="content" class="site-content" tabindex="-1">
		<div class="container">
				<div class="woocommerce"></div>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			
<article id="post-9" class="post-9 page type-page status-publish hentry">
			<div class="entry-content">
			<div class="woocommerce">
<nav class="woocommerce-MyAccount-navigation">
	<ul>
			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--dashboard is-active">
				<a href="http://yosshitaneha.com/account/my-account.php">Dashboard</a>
			</li>
					<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--orders">
				<a href="http://yosshitaneha.com/account/orders.php">Orders</a>
			</li>
			
			
			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--orders">
				<a href="http://yosshitaneha.com/showcart_details.php">Go to cart</a>
			</li>
			
			
			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-account">
				<a href="http://yosshitaneha.com/account/edit-account.php">Account details</a>
			</li>
			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--customer-logout">
				<a href="../logout.php">Logout</a>
			</li>
			</ul>
</nav>




<?
if(isset($_SESSION['email'])){ ?>

<div class="woocommerce-MyAccount-content">
	<div class="woocommerce-notices-wrapper"></div>
	<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
		<thead>
			<tr>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr">Order Number</span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-date"><span class="nobr">Date</span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr">Transaction ID</span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr">Total</span></th>
				
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr">Action</span></th>
				
		    </tr>
		</thead>
		<tbody>
		    <!--get the order details-->
		    <?
		    $sql=mysqli_query($conn,"select * from Order_ent where user_id='".$userid."' ORDER BY id desc");
		    
		    while($sql_result=mysqli_fetch_assoc($sql)){
		        
		        
		         $transaction_id=$sql_result['transaction_id'];
		         $order_id=$sql_result['id'];
		         $date=$sql_result['date'];
		         $amount=$sql_result['amount'];
		         $status=$sql_result['status'];
		         
		        
		        //if($transaction_id){
		        if($status=='success'){
		        ?>
					<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-processing order">
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Order">
						    <? echo $order_id; ?>
						</td>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date" data-title="Date">
                            <? echo $date; ?>
						</td>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Status">
							<? echo $transaction_id; ?>
						</td>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Total">
                            <? echo $amount; ?>
						</td>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="View">
                            <a href="orderDetails.php?id=<?php echo $order_id;?>"><i class="glyphicon glyphicon-eye-open"></i></a>
						</td>
					</tr>
		        <? }
		    }   ?>
		    

						</tbody>
	</table>

	
	

</div>
    
<? }
else{ 
    
    include_once('login_register.php'); ?>
    sa
<?}

?>







</div>
					</div><!-- .entry-content -->
		</article><!-- #post-## -->
		</main><!-- #main -->
	</div><!-- #primary -->


		</div><!-- .col-full -->
	</div>