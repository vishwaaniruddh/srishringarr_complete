<?php include('../config.php');

  $state=$_POST['state'];

       $out='';   
       if($state != ''){
       $sqlm=mysqli_query($conn,"SELECT code,name FROM cities where state_code='".$state."'");
      
   
        while($row=mysqli_fetch_assoc($sqlm)){
                
                $id=$row['code'];
                $name=$row['name'];
                $out[]=['id'=>$id,'name'=>$name];
                
			   } 
      
       }

echo json_encode($out);

?>