<? session_start(); 

$output = "";

if(isset($_SESSION['count']) )
{
    echo "{$_SESSION['count']}";
    $_SESSION['count'] = $_SESSION['count'] + 1;
} else{
    $_SESSION['count'] = 0;
}

echo $output;



?>