<?php include_once('site_header.php'); ?>
	<style>
		.site-content {
        outline: none;
}

.site-content, .header-widget-region {
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
@media (max-width: 66.4989378333em) {
.col-full {
    margin-left: 2.617924em;
    margin-right: 2.617924em;
    padding: 0;
}

}

@media (min-width: 768px){
    
    .col2-set#customer_login .col-1, .col2-set.addresses .col-1 {
    width: 41.1764705882%;
    float: left;
    margin-right: 5.8823529412%;
}

.col2-set .col-1, .col2-set .col-2 {
    margin-bottom: 1.618em;
}

.col-full {
    max-width: 66.4989378333em;
    margin-left: auto;
    margin-right: auto;
    padding: 0 2.617924em;
    box-sizing: content-box;
}

 .widget-area {
    margin-bottom: 2.617924em;
}

.content-area {
    width: 100%;
    float: left;
 
}

.woocommerce-MyAccount-navigation {
    width: 17.6470588235%;
    float: left;
    margin-right: 5.8823529412%;
}

.woocommerce-MyAccount-content {
    width: 76.4705882353%;
    float: right;
    margin-right: 0;
}

}


p {
    margin: 0 0 1.41575em;
}	

.hentry .entry-content .woocommerce-MyAccount-navigation ul {
    margin-left: 0;
    border-top: 1px solid rgba(0, 0, 0, 0.05);
}

ul {
    list-style: disc;
}
ul, ol {
    margin: 0 0 1.41575em 3em;
    padding: 0;
}

.hentry .entry-content .woocommerce-MyAccount-navigation ul li {
    list-style: none;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    position: relative;
}
a {
    color: #227504;
        font-weight: 600;
}
.hentry .entry-content .woocommerce-MyAccount-navigation ul li.woocommerce-MyAccount-navigation-link a {
    text-decoration: none;
    padding: 0.875em 0;
    display: block;
}	
.site-main {
    margin-bottom: 2.617924em;
}

.hentry {
    /*border-bottom: 1px solid #ededed;*/
    margin: 0 0 4.235801032em;
}

article, aside, details, figcaption, figure, footer, header, hgroup, main, menu, nav, section, summary {
    display: block;
}
#content{
        margin: 3% auto;
}

h2{
        color: #484c51;
        font-family: 'Roboto',Helvetica Neue,sans-serif;
    font-weight: 700;
}
form {
    margin-bottom: 1.618em;
}
.form-row-wide {
    clear: both;
    width: 100%;
}
.form-row label {
    display: block;
}

label {
    font-weight: 400;
}
.woocommerce form .form-row .required {
    visibility: visible;
}

.required {
    border-bottom: 0 !important;
    color: #e2401c;
}



.form-row input, .form-row textarea, .form-row select {
    width: 100%;
}

input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], textarea, .input-text {
    border: 1px solid #ededed;
    box-shadow: none;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    -o-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}
input[type='text'], input[type='number'], input[type='email'], input[type='tel'], input[type='url'], input[type='password'], input[type='search'], textarea, .input-text {
    padding: 0.6180469716em;
    background-color: #f2f2f2;
    color: #43454b;
    border: 0;
    -webkit-appearance: none;
    box-sizing: border-box;
    font-weight: normal;

}
button, input, select, textarea {
    font-size: 100%;
    margin: 0;
    vertical-align: baseline;
    *vertical-align: middle;
}

.woocommerce-form__label-for-checkbox {
    cursor: pointer;
    display: block;
}
.woocommerce-form__label-for-checkbox .woocommerce-form__input-checkbox {
    margin-right: 0.3342343017em;
}

input[type='checkbox'], input[type='radio'] {
    padding: 0;
    box-sizing: border-box;
}

button{
    background-color: #227504;
    border-color: #227504;
    color: #ffffff;
    border: 0;
    border-radius: 0;

    cursor: pointer;
    padding: 0.6180469716em 1.41575em;
    text-decoration: none;
    font-weight: 600;
    text-shadow: none;
    display: inline-block;
    -webkit-appearance: none;

}
.panel-title{
    text-align:center;
}
	</style>
	
	<? if(isset($_SESSION['email'])){ ?>
	
	<div id="content" class="site-content" tabindex="-1">
		<div class="container">
			<div class="woocommerce"></div>
	        <div id="primary" class="content-area">
		        <main id="main" class="site-main" role="main">
                    <article id="post-9" class="post-9 page type-page status-publish hentry">
			            <div class="entry-content">
			                <div class="woocommerce">
                                <nav class="woocommerce-MyAccount-navigation">
                            		<ul>
                            			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--dashboard is-active">
                            				<a href="http://yosshitaneha.com/account/my-account.php">Dashboard</a>
                            			</li>
                            					<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--orders">
                            				<a href="http://yosshitaneha.com/account/orders.php">Orders</a>
                            			</li>
                            			
                            			
                            			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--orders">
                            				<a href="http://yosshitaneha.com/showcart_details.php">Go to cart</a>
                            			</li>
                            			
                            			
                            			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-account">
                            				<a href="http://yosshitaneha.com/account/edit-account.php">Account details</a>
                            			</li>
                            			<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--customer-logout">
                            				<a href="../logout.php">Logout</a>
                            			</li>
                            		</ul>
                                </nav>

                                <div class="woocommerce-MyAccount-content">
	                                <div class="woocommerce-notices-wrapper"></div>
                                        <p>Hello <strong><? echo $_SESSION['email'];?></strong> (not <strong><? echo $_SESSION['email'];?></strong>? <a href="../logout.php">Log out</a>)</p>

                                        <p>From your account dashboard you can view your <a href="orders.php">recent orders</a>, manage your <a href="edit-account.php">shipping and billing addresses</a>, and <a href="edit-account.php">edit your password and account details</a>.</p>



	<?
	$sql=mysqli_query($conn,"select * from Registration where registration_id='".$userid."'");
	
	$sql_result=mysqli_fetch_assoc($sql);
	
	$state=$sql_result['state'];
	$city=$sql_result['city'];
	
	
	if(empty($state) || empty($city)){ ?>   
	  <h2>
	      <a href="edit-account.php">
	          "Please complete your profile... !";
	      </a>
	  </h2> 
	<?}
	?>

</div>
</div>
					</div><!-- .entry-content -->
		</article><!-- #post-## -->
		</main><!-- #main -->
	</div><!-- #primary -->


		</div><!-- .col-full -->
	</div>
	
	
	
	
	
	
	
<?	} else{ 

include_once('login_register.php');
} ?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



</body>
</html>


