<?php
header('Cache-Control: no cache');
session_cache_limiter('private_no_expire');
session_start();
include("config.php");
$userid=$_SESSION['gid']; 

$_SESSION['cart'] = 0;

$orders = "select * from Order_ent where user_id='".$userid."'";
//echo $orders;
$order = mysql_query($orders);
// $result = mysql_fetch_array($order);

/*while($result = mysql_fetch_array($order)){
    echo '<pre>';print_r($result);echo '</pre>';
}*/

/*
$date4=date_create("2020-03-15 14:20:32");
$date5 = date('y-m-d h:m:s');
if($date4>$date5){
echo 'true';
} else {
echo 'false';
}*/
?> 
<!DOCTYPE html>
<html>
    <head>
        <title>SA</title>
        <link rel="" href="logo/Untitled-2 copy.jpg"/><link rel="icon" href="logo/Untitled-2 copy.jpg" type="image/x-icon" />
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap s JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Wedding Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
        Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <script src="js/simpleCart.min.js"></script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function(){$(".memenu").memenu();});</script>	
        <!-- /start menu -->
        <link href="css/form.css" rel="stylesheet" type="text/css" media="all" />
        
        <style>
            .alert {
                padding: 20px;
                background-color: #f44336;
                color: white;
            }
            
            .closebtn {
                margin-left: 15px;
                color: white;
                font-weight: bold;
                float: right;
                font-size: 22px;
                line-height: 20px;
                cursor: pointer;
                transition: 0.3s;
            }
            
            .closebtn:hover {
                color: black;
            }
            
            #snackbar {
                visibility: hidden;
                min-width: 250px;
                margin-left: -125px;
                background-color: #333;
                color: #fff;
                text-align: center;
                border-radius: 2px;
                padding: 16px;
                position: fixed;
                z-index: 1;
                left: 50%;
                bottom: 30px;
                font-size: 17px;
            }
            
            #snackbar.showalrt{
                visibility: visible;
                -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
                animation: fadein 0.5s, fadeout 0.5s 2.5s;
            }
            
            @-webkit-keyframes fadein {
                from {bottom: 0; opacity: 0;} 
                to {bottom: 30px; opacity: 1;}
            }
            
            @keyframes fadein {
                from {bottom: 0; opacity: 0;}
                to {bottom: 30px; opacity: 1;}
            }
            
            @-webkit-keyframes fadeout {
                from {bottom: 30px; opacity: 1;} 
                to {bottom: 0; opacity: 0;}
            }
            
            @keyframes fadeout {
                from {bottom: 30px; opacity: 1;}
                to {bottom: 0; opacity: 0;}
            }
            
            
            .drop1{ border:0; color:#EEE; background:#800000;
            font-size:18px; font-weight:bold; padding:2px 8px; width:150px;
            *width:160px; *background:#fff; -webkit-appearance: none; }
            
            #mainselection { overflow:hidden; width:150px;
            -moz-border-radius: 9px 9px 9px 9px;
            -webkit-border-radius: 9px 9px 9px 9px;
            border-radius: 9px 9px 9px 9px;
            box-shadow: 1px 1px 11px #800000;
            background: url("http://www.danielneumann.com/wp-content/uploads/2011/01/arrow.gif") no-repeat scroll 219px 5px #fff; 
            }
            
            /*Table*/
            .table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px auto;
		border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
	.table-wrapper .btn {
		float: right;
		color: #333;
    	background-color: #fff;
		border-radius: 3px;
		border: none;
		outline: none !important;
		margin-left: 10px;
	}
	.table-wrapper .btn:hover {
        color: #333;
		background: #f2f2f2;
	}
	.table-wrapper .btn.btn-primary {
		color: #fff;
		background: #03A9F4;
	}
	.table-wrapper .btn.btn-primary:hover {
		background: #03a3e7;
	}
	.table-title .btn {		
		font-size: 13px;
		border: none;
	}
	.table-title .btn i {
		float: left;
		font-size: 21px;
		margin-right: 5px;
	}
	.table-title .btn span {
		float: left;
		margin-top: 2px;
	}
	.table-title {
		color: #fff;
		background: #4b5366;		
		padding: 16px 25px;
		margin: -20px -25px 10px;
		border-radius: 3px 3px 0 0;
    }
    .table-title h2 {
		margin: 5px 0 0;
		font-size: 24px;
	}
	.show-entries select.form-control {        
        width: 60px;
		margin: 0 5px;
	}
	.table-filter .filter-group {
        float: right;
		margin-left: 15px;
    }
	.table-filter input, .table-filter select {
		height: 34px;
		border-radius: 3px;
		border-color: #ddd;
        box-shadow: none;
	}
	.table-filter {
		padding: 5px 0 15px;
		border-bottom: 1px solid #e9e9e9;
		margin-bottom: 5px;
	}
	.table-filter .btn {
		height: 34px;
	}
	.table-filter label {
		font-weight: normal;
		margin-left: 10px;
	}
	.table-filter select, .table-filter input {
		display: inline-block;
		margin-left: 5px;
	}
	.table-filter input {
		width: 200px;
		display: inline-block;
	}
	.filter-group select.form-control {
		width: 110px;
	}
	.filter-icon {
		float: right;
		margin-top: 7px;
	}
	.filter-icon i {
		font-size: 18px;
		opacity: 0.7;
	}	
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
		padding: 12px 15px;
		vertical-align: middle;
    }
	table.table tr th:first-child {
		width: 60px;
	}
	table.table tr th:last-child {
		width: 80px;
	}
    table.table-striped tbody tr:nth-of-type(odd) {
    	background-color: #fcfcfc;
	}
	table.table-striped.table-hover tbody tr:hover {
		background: #f5f5f5;
	}
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }	
	table.table td a {
		font-weight: bold;
		color: #566787;
		display: inline-block;
		text-decoration: none;
	}
	table.table td a:hover {
		color: #2196F3;
	}
	table.table td a.view {        
		width: 30px;
		height: 30px;
		color: #2196F3;
		border: 2px solid;
		border-radius: 30px;
		text-align: center;
    }
    table.table td a.view i {
        font-size: 22px;
		margin: 2px 0 0 1px;
    }   
	table.table .avatar {
		border-radius: 50%;
		vertical-align: middle;
		margin-right: 10px;
	}
	.status {
		font-size: 30px;
		margin: 2px 2px 0 0;
		display: inline-block;
		vertical-align: middle;
		line-height: 10px;
	}
    .text-success {
        color: #10c469;
    }
    .text-info {
        color: #62c9e8;
    }
    .text-warning {
        color: #FFC107;
    }
    .text-danger {
        color: #ff5b5b;
    }
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }	
    .pagination li.active a {
        background: #03A9F4;
    }
    .pagination li.active a:hover {        
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    } 
        </style>
    </head>
    <body > 
        <?php include("addtocartpopup.php");?>
        <?php include("requiredfields.php");?>
    
        <div class="top_bg">
        	<div class="container">
        		<div class="header_top-sec">
        			<?php include('topbar.php')?>
        	    </div>
            </div>
            <div class="header-top">
        		<div class="container">	
        		    <!---->
        		    <div class="" style=" margin-top:-px; ">
        			  <?php include('menu.php')?>
        			</div>
        			
                    <div class="table-wrapper">
                        <div class="table-title">
                            <div class="row">
                                <div class="col-sm-4">
            						<h2>Order <b>Details</b></h2>
            					</div>
            					<div class="col-sm-8">						
            						<a href="#" class="btn btn-primary"><i class="material-icons">&#xE863;</i> <span>Refresh List</span></a>
            						<a href="#" class="btn btn-info"><i class="material-icons">&#xE24D;</i> <span>Export to Excel</span></a>
            					</div>
                            </div>
                        </div>
            			<div class="table-filter">
            				<div class="row">
                                <!--<div class="col-sm-3">
            						<div class="show-entries">
            							<span>Show</span>
            							<select class="form-control">
            								<option>5</option>
            								<option>10</option>
            								<option>15</option>
            								<option>20</option>
            							</select>
            							<span>entries</span>
            						</div>
            					</div>-->
                                <div class="col-sm-9">
            						<button type="button" class="btn btn-primary"><i class="fa fa-search"></i></button>
            						<div class="filter-group">
            							<label>Name</label>
            							<input type="text" class="form-control">
            						</div>
            						<!--<div class="filter-group">
            							<label>Location</label>
            							<select class="form-control">
            								<option>All</option>
            								<option>Berlin</option>
            								<option>London</option>
            								<option>Madrid</option>
            								<option>New York</option>
            								<option>Paris</option>								
            							</select>
            						</div>-->
            						<div class="filter-group">
            							<label>Status</label>
            							<select class="form-control">
            								<option>Any</option>
            								<option>Delivered</option>
            								<option>Shipped</option>
            								<option>Pending</option>
            								<option>Cancelled</option>
            							</select>
            						</div>
            						<span class="filter-icon"><i class="fa fa-filter"></i></span>
                                </div>
                            </div>
            			</div>
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Customer</th>
            						<th>Order Date</th>						
                                    <th>Status</th>						
            						<th>Net Amount</th>
            						<th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $cnt = 1;
                                    while($result = mysql_fetch_array($order)){
                                    $status = 'Pending';
                                    $statusClass = 'text-warning';
                                    if($result['status'] == 0){
                                        $status = 'Pending';
                                        $statusClass = 'text-warning';
                                    } else if($result['status'] == 1){
                                        $status = 'Process';
                                        $statusClass = 'text-info';
                                    } else if($result['status'] == 2){
                                        $status = 'Dispatch';
                                        $statusClass = 'text-info';
                                    } else if($result['status'] == 3){
                                        $status = 'Complete';
                                        $statusClass = 'text-success';
                                    }else if($result['status'] == 4){
                                        $status = 'Canceled';
                                        $statusClass = 'text-danger';
                                    }
                                    
                                ?>
                                    <tr>
                                        <td><?php echo $cnt;?></td>
                                        <td><a href="#"><img src="/examples/images/avatar/1.jpg" class="avatar" alt="Avatar"> Michael Holz</a></td>
                                        <td><?php echo $result['date'];?></td>                        
                						<td><span class="status <?php echo $statusClass;?>">&bull;</span> <?php echo $status; ?></td>
                						<td><?php echo $result['amount'];?></td>
                						<td><a href="#" class="view" title="View Details" data-toggle="tooltip"><i class="material-icons">&#xE5C8;</i></a></td>
                                    </tr>
                                <?php $cnt++;} ?>
            					<!--<tr>
                                    <td>2</td>
                                    <td><a href="#"><img src="/examples/images/avatar/2.jpg" class="avatar" alt="Avatar"> Paula Wilson</a></td>
                                    <td>Madrid</td>                       
            						<td>Jun 21, 2017</td>
            						<td><span class="status text-info">&bull;</span> Shipped</td>
            						<td>$1,260</td>
            						<td><a href="#" class="view" title="View Details" data-toggle="tooltip"><i class="material-icons">&#xE5C8;</i></a></td>
                                </tr>
            					<tr>
                                    <td>3</td>
                                    <td><a href="#"><img src="/examples/images/avatar/3.jpg" class="avatar" alt="Avatar"> Antonio Moreno</a></td>
            						<td>Berlin</td>
                                    <td>Jul 04, 2017</td>
                                    <td><span class="status text-danger">&bull;</span> Cancelled</td>
            						<td>$350</td>
            						<td><a href="#" class="view" title="View Details" data-toggle="tooltip"><i class="material-icons">&#xE5C8;</i></a></td>                        
                                </tr>
            					<tr>
                                    <td>4</td>
                                    <td><a href="#"><img src="/examples/images/avatar/4.jpg" class="avatar" alt="Avatar"> Mary Saveley</a></td>
            						<td>New York</td>
                                    <td>Jul 16, 2017</td>						
            						<td><span class="status text-warning">&bull;</span> Pending</td>
            						<td>$1,572</td>
            						<td><a href="#" class="view" title="View Details" data-toggle="tooltip"><i class="material-icons">&#xE5C8;</i></a></td>
                                </tr>
            					<tr>
                                    <td>5</td>
                                    <td><a href="#"><img src="/examples/images/avatar/5.jpg" class="avatar" alt="Avatar"> Martin Sommer</a></td>
            						<td>Paris</td>
                                    <td>Aug 04, 2017</td>
            						<td><span class="status text-success">&bull;</span> Delivered</td>
            						<td>$580</td>
            						<td><a href="#" class="view" title="View Details" data-toggle="tooltip"><i class="material-icons">&#xE5C8;</i></a></td>
                                </tr>-->
                            </tbody>
                        </table>
            			<div class="clearfix">
                            <div class="hint-text">Showing <b>5</b> out of <b>25</b> entries</div>
                            <ul class="pagination">
                                <li class="page-item disabled"><a href="#">Previous</a></li>
                                <li class="page-item"><a href="#" class="page-link">1</a></li>
                                <li class="page-item"><a href="#" class="page-link">2</a></li>
                                <li class="page-item"><a href="#" class="page-link">3</a></li>
                                <li class="page-item active"><a href="#" class="page-link">4</a></li>
                                <li class="page-item"><a href="#" class="page-link">5</a></li>
            					<li class="page-item"><a href="#" class="page-link">6</a></li>
            					<li class="page-item"><a href="#" class="page-link">7</a></li>
                                <li class="page-item"><a href="#" class="page-link">Next</a></li>
                            </ul>
                        </div>
                    </div>
    		 
        			 <div class="clearfix"> </div>
        			 			 
        		</div>
        		<div class="clearfix"> </div>
            </div>
        </div>
        <?php include('footer.php')?>
    </body>
</html>