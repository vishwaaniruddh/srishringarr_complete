

<div class="row u-columns col2-set" id="customer_login">

	<div class="u-column1 col-md-6">


		<h2>Login</h2>

		<form class="woocommerce-form woocommerce-form-login login" action="../logincode.php" method="post">

			
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Username or email address&nbsp;<span class="required">*</span></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="usernm" id="usernm" autocomplete="username" value="">			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="password">Password&nbsp;<span class="required">*</span></label>
				<span class="password-input"><input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="pass" id="pass" autocomplete="current-password"><span class="show-password-input"></span></span>
			</p>
			
			<p class="form-row">
				<input type="hidden" id="woocommerce-login-nonce" name="woocommerce-login-nonce" value="7032783d58"><input type="hidden" name="_wp_http_referer" value="/staging/sid/my-account/">
				<button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="Log in">Log in</button>
			</p>
			<p class="woocommerce-LostPassword lost_password">
				<a class="forget_password" href="forget_password.php" style="color:#227504 !important;">Lost your password</a>
			</p>
		</form>
	</div>

	<div class="u-column2 col-md-6">

		<h2>Register</h2>

<style>
 

#overlay {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-color: #000;
filter:alpha(opacity=70);
-moz-opacity:0.7;
-khtml-opacity: 0.7;
opacity: 0.7;
z-index: 0;
display: none;
}
.cnt a{
text-decoration: none;
}
.popup1{
width: 100%;
margin: 0 auto;
display: none;
position: fixed;
z-index: 101;
}
.cnt{

width: 500px;
height: 300px;
min-height: 150px;
padding: 0px;
margin: 0px auto;
background: #FFFFFF;
position: relative;
z-index: 103;

border-radius: 5px;
box-shadow: 0 2px 5px #000;
}
.cnt p{
clear: both;
color: #555555;
text-align: justify;
}
.cnt p a{
color: #d91900;
font-weight: bold;
}
.cnt .x{
float: right;

top: -25px;
width: 34px;
}
.cnt .x:hover{
cursor: pointer;
}

.myButton {
	-moz-box-shadow:inset 0px 2px 0px 0px #cf866c;
	-webkit-box-shadow:inset 0px 2px 0px 0px #cf866c;
	box-shadow:inset 0px 2px 0px 0px #cf866c;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #d0451b), color-stop(1, #ed3713));
	background:-moz-linear-gradient(top, #d0451b 5%, #ed3713 100%);
	background:-webkit-linear-gradient(top, #d0451b 5%, #ed3713 100%);
	background:-o-linear-gradient(top, #d0451b 5%, #ed3713 100%);
	background:-ms-linear-gradient(top, #d0451b 5%, #ed3713 100%);
	background:linear-gradient(to bottom, #d0451b 5%, #ed3713 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#d0451b', endColorstr='#ed3713',GradientType=0);
	background-color:#d0451b;
	-moz-border-radius:26px;
	-webkit-border-radius:26px;
	border-radius:26px;
	border:2px solid #942911;
	display:inline;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:23px;
	padding:9px 32px;
	text-decoration:none;
	text-shadow:0px 1px 0px #854629;
}

.cnt{
    position:absolute;
    top:20%;
    left:-20%;
}

.cnt2{
height: 50px;
background: #00a0e4;
color: #fff;
padding:9px 32px;
position: relative;
z-index: 103;
}
.top_bg{
    overflow:hidden;
}


.popup{
width: 100%;
margin: 0 auto;
display: none;
position: fixed;
z-index: 101;
}

</style>
<script type='text/javascript'>

function chkf1()
{
//alert("test");
var overlay = $('<div id="overlay1"></div>');
overlay.show();
overlay.appendTo(document.body);
$('.popup1').show();
}

var bol=true;
function validation1()
{
    try
    {
        var mob=document.getElementById('mob').value;
        var pass=document.getElementById('passwd').value;
        var rpass=document.getElementById('rpass').value;
        if(mob.length != 10) {
            alert("Phone number must be 10 digits.");
            //document.getElementById('mob').focus();
            bol=false;
        }
        else if(pass!=rpass)
        {
        alert("Password does not match!");
        bol=false;
        }
else
{

bol=true;
}
}catch(exe)
{
    alert(exe);
    
}
return bol;
}


function sub1()
{

    if(validation1())
{    
 
var fname=document.getElementById('fname').value;
var lname=document.getElementById('lname').value;
var email=document.getElementById('emailid').value;
var mob=document.getElementById('mob').value;
//alert(mob);
if (document.getElementById('rd1').checked) {
  rd = document.getElementById('rd1').value;
}
if (document.getElementById('rd2').checked) {
  rd= document.getElementById('rd2').value;
}
//var rd= $("input:radio[name=radio]:checked").val();
var pass=document.getElementById('passwd').value;
//alert(pass);


$.ajax({
   type: 'POST',    
url:'../process_reg.php',
data:'fname='+fname+'&lname='+lname+'&email='+email+'&mob='+mob+'&pass='+pass+'&rd='+rd,

success: function(msg){
//alert(msg);

if(msg=="error")
{

alert("Error");
}
else
{
if(msg==2)
{
alert("Email id already exists");
}else if(msg==3)
{
    //alert("Mobile Number is already registered");
    alert("You are already registered");
}
else if(msg==50)
{
    alert("Error please try again later");
    window.open("../index.php","_self");
    
}else

{
document.getElementById('em1').value=msg;
  //document.getElementById('show').innerHTML=msg;
chkf1();
}
}
//alert(msg);
         }
     });

}
return false; 
}


function verify1()
{

var cd=document.getElementById('cd1').value;
var email=document.getElementById('em1').value;
//alert(cd);
//alert(email);
$.ajax({
   type: 'POST',    
url:'../verification.php',
data:'email='+email+'&cd='+cd,

success: function(msg){
//alert("check");
//alert(msg);
if(msg==1)
{
alert("Verification successfull! Login to Continue ..");
window.open("my-account.php",'_self');
}
else
{
alert("Verification code is incorrect");
}


         }
     });
}




function verify()
{
    //alert("check");
    //var cd=document.getElementById('cd').value;
    var email=document.getElementById('emver').value;
    //alert(email);
    $.ajax({
        type: 'POST',    
        url:'../forgotpass.php',
        data:'email='+email,
    
        success: function(msg){
            //alert("check");
            //alert(msg);
            if(msg==0)
            {
                alert("Email is incorrect");
            }
        }
    });
    //return false; 
}


function checkcode()
{
var cd=document.getElementById('cd').value;
//var name=document.getElementById('usernm').value;
$.ajax({
   type: 'POST',    
    url:'../checkcode.php',
    data:'cd='+cd,//+'&name='+name,

success: function(msg){
//alert("check");
alert(msg);
if(msg==1)
{
    alert("Password reset successfully");
    window.location.href="my-account.php";
}
else
{
    alert("Verification code is incorrect");
}


    }
 });
}


function chkf()
{
/*var name=document.getElementById('email').value;

$.ajax({
   type: 'POST',    
url:'forgot.php',
data:'name='+name,

success: function(msg){
//alert("check");
//alert(msg);
if(msg==1)
{*/
var overlay = $('<div id="overlay"></div>');
overlay.show();
overlay.appendTo(document.body);
$('.popup').show();
/*}
else
{
alert("Verification code is incorrect");
}


         }
     });

*/
}
</script>



</head>
<body> 
<div class="top_bg">


<input type="hidden" id="em1" name="em1">
<div class='popup1'>
<div class='cnt'>
<div class="cnt2">
 <center><h3><b>E-Commerce</b></h3></center>
</div>
</br><br/></br>
<center>
Please check your email for verification code.

<b style="font-size:16px;">Enter code :</b> <input type="text" id="cd1" style="width:200px; height:30px;" name="cd1">
<br/><br/><br/><br/>
<a href="javascript:void(0)" class="myButton" onclick="verify1();">Continue</a>
</center>
</div>
</div>


<div class='popup' >
<div class='cnt223'>
<div class="cnt223321">
 <center><h3><b>E-Commerce</b></h3></center>
</div>
</br></br>
<center>
<b style="font-size:16px;">Enter Email :</b> <input type="text" id="emver" style="width:200px; height:30px;" name="emver"><br/>
<a href="javascript:void(0)" style="margin-right:-80px;color:red" onclick="verify();">Send code</a><br/>
<b style="font-size:16px;">Enter code :</b> <input type="text" id="cd" style="width:200px; height:30px;" name="cd">
<br/><br/>Code send to your email.
<a href="javascript:void(0)" style="margin-right:-80px;color:red" onclick="verify();"><u>Resend code</u></a>
<br/><br/>
<a href="javascript:void(0)" class="myButton" onclick="checkcode();">Submit</a>&nbsp;&nbsp;
<a href="login.php" class="myButton" >Cancel</a>
</center>
</div>
</div>




<div class="container" style="width:100%">
	  
	 <div class="registration">
		 <div class="registration_left">
	
			 <script>
				(function() {
			
				// Create input element for testing
				var inputs = document.createElement('input');
				
				// Create the supports object
				var supports = {};
				
				supports.autofocus   = 'autofocus' in inputs;
				supports.required    = 'required' in inputs;
				supports.placeholder = 'placeholder' in inputs;
			
				// Fallback for autofocus attribute
				if(!supports.autofocus) {
					
				}
				
				// Fallback for required attribute
				if(!supports.required) {
					
				}
			
				// Fallback for placeholder attribute
				if(!supports.placeholder) {
					
				}
				
				// Change text inside send button on submit
				var send = document.getElementById('register-submit');
				if(send) {
					send.onclick = function () {
						this.innerHTML = '...Sending';
					}
				}
			
			 })();
			 </script>


                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="panel-title">Sign Up</div>
                            
                        </div>  
                        <div class="registration_form" style="padding: 20px;">
			 <!-- Form -->
				<form id="registration_form"  action="" method="post" onsubmit="return sub1();">
					<div>
					    
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">First Name&nbsp;<span class="required">*</span></label>
				
				<input class="woocommerce-Input woocommerce-Input--text input-text" placeholder="first name:" type="text" name="fname" id="fname" tabindex="1" required autofocus>
				</p>
				
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Last Name&nbsp;<span class="required">*</span></label>
				
					<input class="woocommerce-Input woocommerce-Input--text input-text" placeholder="last name:" type="text" name="lname" id="lname" tabindex="2" required autofocus>
				</p>
				
				
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Email&nbsp;<span class="required">*</span></label>
				
					<input class="woocommerce-Input woocommerce-Input--text input-text" placeholder="email address:" name="emailid" id="emailid" type="email" tabindex="3" required>
				</p>
				
				
				
				
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Mobile&nbsp;<span class="required">*</span></label>
				
					<input class="woocommerce-Input woocommerce-Input--text input-text" placeholder="Mobile:" type="text" name="mob" id="mob" tabindex="3" required>
				</p>
				
				
				
				
					</div>
<!--<div>
						<label>
							<input placeholder="Address:" type="text" name="add" id="add" tabindex="2" required autofocus>
						</label>
					</div>		-->		
						<div class="sky_form1">
							<ul>
								<li><label class="radio left"><input type="radio" name="radio" value="Male" id="rd1" checked=""><i></i>Male</label></li>
								<li><label class="radio"><input type="radio" name="radio" id="rd2" value="Female"><i></i>Female</label></li>
								<div class="clearfix"></div>
							</ul>
						</div>					
					<div>
					    
					    	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Password&nbsp;<span class="required">*</span></label>
				
					<input class="woocommerce-Input woocommerce-Input--text input-text" placeholder="password" type="password" name="passwd" id="passwd" tabindex="4" required>
				</p>
				
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Retype Password&nbsp;<span class="required">*</span></label>
				
					<input class="woocommerce-Input woocommerce-Input--text input-text" placeholder="retype password" type="password" id="rpass" tabindex="4" required>
				</p>
				
					</div>
<div>
						<label>
							We will send You a verification code, please check your email.
						</label>
					</div>	
					<div>
						<input type="submit" class="btn btn-success" value="create an account" id="register-submit" >
					</div>
				
				</form>
				<!-- /Form -->
			 </div>
		 </div>
	
		 <div class="clearfix"></div>
	 </div>
</div>

               
               
                
         </div> 

	</div>

</div>
