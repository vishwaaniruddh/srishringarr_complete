<? session_start();

include('config.php');

echo $currency_symbol . currencyAmount('USD','2656');

?>