<?  function currencyAmount($currency,$product_amount){
    $req_url = 'https://v6.exchangerate-api.com/v6/e19da6d8e3ff6d2c76ee44be/latest/USD';
    $response_json = file_get_contents($req_url);


var_dump($response_json);
    if(false !== $response_json) {
            $response = json_decode($response_json);
            
            
        
            if('success' === $response->result) {
                $base_price = 1; // Your price in USD
                $INR_price = round(($base_price * $response->conversion_rates->INR), 2);
                $dol_selling_price = round($product_amount / $INR_price ,2 ) ;
                    if($currency=='USD'){

                        return $dol_selling_price;
                    }else{
                        return $product_amount ; 
                    }
            }
        }
}

echo currencyAmount('INR','765');
?>