<?php include('header.php'); 

$product_type = $_GET['type'];
$product_id = $_GET['id'];
$pricefilter = $_GET['pricefilter'];
?>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://pagination.js.org/dist/2.1.4/pagination.min.js"></script>
<link rel="stylesheet" href="https://pagination.js.org/dist/2.1.4/pagination.css"/>
<style>
    .paginationjs .paginationjs-pages li.active>a{
            z-index: 3;
    color: #fff;
    background-color: #ba933e;
    border-color: #ba933e;
    cursor: default;
    }
    .paginationjs .paginationjs-pages li:not(:last-child) {
    margin-right: 8px;
}
.paginationjs .paginationjs-pages li {
    border-right: 1px solid #aaa !important;
    border : 1px solid #aaa !important;
}
.paginationjs .paginationjs-pages li>a{
    font-size:18px;
}
</style>
<main class="mainContent" role="main">
    
    <section id="pageContent">
    <div class="container">
        <div class="pageCollectionInner mb20 pb-md-30">
            <div id="shopify-section-vela-template-collections" class="shopify-section">
<div class="rowFlex rowFlexMargin">
    
                <div class="col-xs-12 col-sm-6 col-md-4 col-xl-3">
                    <div class="velaBoxCollection mb30 pb-md-30"><div class="velaBoxCollectionImage">
                                <a href="/collections/backpacks">

<div class="p-relative">
    <div class="product-card__image" style="padding-top:100.0%;">
        <img class="product-card__img lazyautosizes ls-is-cached lazyloaded" data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]" data-aspectratio="1.0" data-ratio="1.0" data-sizes="auto" alt="Backpacks" data-srcset="//cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_180x.jpg?v=1589429021 180w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_360x.jpg?v=1589429021 360w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_540x.jpg?v=1589429021 540w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_720x.jpg?v=1589429021 720w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_900x.jpg?v=1589429021 900w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1080x.jpg?v=1589429021 1080w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1296x.jpg?v=1589429021 1296w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1512x.jpg?v=1589429021 1512w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1728x.jpg?v=1589429021 1728w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1944x.jpg?v=1589429021 1944w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2160x.jpg?v=1589429021 2160w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2376x.jpg?v=1589429021 2376w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2592x.jpg?v=1589429021 2592w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2808x.jpg?v=1589429021 2808w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_3024x.jpg?v=1589429021 3024w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_4320x.jpg?v=1589429021 4320w" sizes="323px" srcset="//cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_180x.jpg?v=1589429021 180w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_360x.jpg?v=1589429021 360w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_540x.jpg?v=1589429021 540w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_720x.jpg?v=1589429021 720w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_900x.jpg?v=1589429021 900w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1080x.jpg?v=1589429021 1080w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1296x.jpg?v=1589429021 1296w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1512x.jpg?v=1589429021 1512w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1728x.jpg?v=1589429021 1728w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_1944x.jpg?v=1589429021 1944w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2160x.jpg?v=1589429021 2160w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2376x.jpg?v=1589429021 2376w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2592x.jpg?v=1589429021 2592w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_2808x.jpg?v=1589429021 2808w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_3024x.jpg?v=1589429021 3024w, //cdn.shopify.com/s/files/1/0276/4616/5110/collections/bag_4320x.jpg?v=1589429021 4320w">
    </div>
    <div class="placeholder-background placeholder-background--animation" data-image-placeholder=""></div>
</div>
</a>
                            </div><div class="velaBoxCollectionContent">
                            <h3 class="collectionTitle">
                                <a href="/collections/backpacks" title="Backpacks">Backpacks</a>
                            </h3><div class="collectionProductCount">17 products</div><div class="collectionButtonDetail">
                                    <a href="/collections/backpacks" title="Shop the collection">
                                        Shop the collection
                                    </a>
                                </div></div>
                    </div>
                </div>
    </div>
</div>
        </div>
    </div>
</section>
</main>

<?php include('footer.php'); ?>