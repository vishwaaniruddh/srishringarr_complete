<?php

namespace Razorpay\Api\Errors;

class ServerError extends Error
{
}