<? session_start();

$cur = $_POST['cur'];
$_SESSION['cur'] = $cur ; 

?>