<? session_start(); 

var_dump($_SERVER);
echo $_SERVER['DOCUMENT_ROOT'] .'/yosshitaneha/cart.php' ;
?>