<div id="shopify-section-vela-footer" class="shopify-section"><footer id="velaFooter">
    <div class="footerCenter">
        <div class="container">
            <div class="footerCenterInner">
                <div class="rowFlex rowFlexMargin">
                    <div class="col-xs-12 col-sm-6 col-md-3 mb30">
                        <div class="footerInfo"><div class="infoImage"><a href="/" style="width: 130px;">                                       
                                        

<div class="p-relative">
    <div class="product-card__image" style="padding-top:18.461538461538463%;">
        <img class="product-card__img lazyautosizes lazyloaded" data-widths="[180,360,540,720,900,1080,1296,1512,1728,1944,2160,2376,2592,2808,3024,4320]" data-aspectratio="5.416666666666667" data-ratio="5.416666666666667" data-sizes="auto" alt="" data-srcset="//cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_180x.png?v=1589385475 180w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_360x.png?v=1589385475 360w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_540x.png?v=1589385475 540w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_720x.png?v=1589385475 720w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_900x.png?v=1589385475 900w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1080x.png?v=1589385475 1080w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1296x.png?v=1589385475 1296w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1512x.png?v=1589385475 1512w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1728x.png?v=1589385475 1728w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1944x.png?v=1589385475 1944w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2160x.png?v=1589385475 2160w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2376x.png?v=1589385475 2376w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2592x.png?v=1589385475 2592w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2808x.png?v=1589385475 2808w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_3024x.png?v=1589385475 3024w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_4320x.png?v=1589385475 4320w" sizes="130px" srcset="//cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_180x.png?v=1589385475 180w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_360x.png?v=1589385475 360w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_540x.png?v=1589385475 540w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_720x.png?v=1589385475 720w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_900x.png?v=1589385475 900w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1080x.png?v=1589385475 1080w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1296x.png?v=1589385475 1296w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1512x.png?v=1589385475 1512w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1728x.png?v=1589385475 1728w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_1944x.png?v=1589385475 1944w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2160x.png?v=1589385475 2160w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2376x.png?v=1589385475 2376w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2592x.png?v=1589385475 2592w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_2808x.png?v=1589385475 2808w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_3024x.png?v=1589385475 3024w, //cdn.shopify.com/s/files/1/0276/4616/5110/files/logo-white_4320x.png?v=1589385475 4320w">
    </div>
    <div class="placeholder-background placeholder-background--animation" data-image-placeholder=""></div>
</div>


                                    </a>
                                </div><div class="footerSocial">
                                    <div class="d-flex velaSocialFooter">
    <a target="_blank" href="https://www.facebook.com/velatheme">
        <i class="fa fa-facebook"></i>
    </a>
    <a target="_blank" href="https://twitter.com/velatheme">
        <i class="fa fa-twitter"></i>
    </a>
    <a target="_blank" href="https://www.instagram.com/velatheme/">
        <i class="fa fa-instagram"></i>
    </a>
    <a target="_blank" href="https://www.pinterest.com/velatheme/">
        <i class="fa fa-pinterest"></i>
    </a>
<a target="_blank" href="https://velatheme.com">
        <i class="fa fa-youtube-play"></i>
    </a>
</div>
                                </div></div>
                    </div><div class="col-xs-12 col-sm-6 col-md-3 mb30"><div class="velaFooterMenu"><h4 class="velaFooterTitle">Information Company</h4>
	
	<div class="velaContent" style="">
		<ul class="velaFooterLinks list-unstyled">
			
				<li class="">
					<a href="/account" title="">My Account</a>
				</li>
			
				<li class="">
					<a href="/" title="">Track Your Order</a>
				</li>
			
				<li class="">
					<a href="/pages/faqs" title="">FAQs</a>
				</li>
			
				<li class="">
					<a href="/" title="">Payment Methods</a>
				</li>
			
				<li class="">
					<a href="/policies/shipping-policy" title="">Shipping Guide</a>
				</li>
			
				<li class="">
					<a href="http://velatheme.com/guide/velatheme/product_pages.html" title="">Products Support</a>
				</li>
			
				<li class="">
					<a href="/" title="">Gift Card Balance</a>
				</li>
			
		</ul>
	</div>
</div>
                            
                        </div><div class="col-xs-12 col-sm-6 col-md-3 mb30"><div class="velaFooterMenu"><h4 class="velaFooterTitle">More From Rubix</h4>
	
	<div class="velaContent" style="">
		<ul class="velaFooterLinks list-unstyled">
			
				<li class="">
					<a href="/pages/about-us" title="">About Rubix</a>
				</li>
			
				<li class="">
					<a href="/pages/about-us" title="">Our Guarantees</a>
				</li>
			
				<li class="">
					<a href="/policies/terms-of-service" title="">Terms and Conditions</a>
				</li>
			
				<li class="">
					<a href="/policies/privacy-policy" title="">Privacy Policy</a>
				</li>
			
				<li class="">
					<a href="/policies/refund-policy" title="">Return Policy</a>
				</li>
			
				<li class="">
					<a href="/policies/refund-policy" title="">Delivery &amp; Return</a>
				</li>
			
				<li class="">
					<a href="/" title="">Sitemap</a>
				</li>
			
		</ul>
	</div>
</div>
                        </div><div class="col-xs-12 col-sm-6 col-md-3 mb30">
                            <div class="footerAbout">
                                <h5>Let’s Talk</h5>
<div class="d-flex mb30">
   <div><i class="icons icon-earphones-alt"></i></div>
<div>+391 (0)35 2568 4593 <br><u>hello@domain.com</u>
</div>
</div>
<h5>Find Us</h5>
<div class="d-flex">
<div><i class="icons icon-location-pin"></i></div>
<div>502 New Design Str<br>Melbourne, Australia</div>
</div>
                            </div>
                        </div></div>
            </div>
        </div>
    </div>
    <div class="footerCopyRight">
        <div class="container">
            <div class="footerCopyRightInner clearfix"><div class="velaCopyRight pull-left">
                        <a href="/"><b>© 2020 Rubix.</b></a> All Rights Reserved
                    </div><div class="velaPayment pull-right hidden-xs hidden-sm">
                    <div class="vela-content">
                        
                        <img class="img-responsive" alt="" src="//cdn.shopify.com/s/files/1/0276/4616/5110/files/paymenlogo.png?v=1589386819">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>


<div id="shopify-section-vela-template-notification" class="shopify-section">
</div>
<script type="text/javascript">
        $(window).on("load",function() {
            var dateCookie = new Date();
            var minutes = 60;
            dateCookie.setTime(dateCookie.getTime() + (minutes * 60 * 1000));
            setTimeout(function () {
                if ( document.body.classList.contains('template-collection') && ($("#velaNotifiCollection").length > 0) && ($.cookie('velaNotifiCollectioin') != 'closed')) {
                    $.fancybox.open({
                        src  : '#velaNotifiCollection',
                        opts : {
                            padding: 0,
                            beforeLoad: function(){
                                $('#velaNotifiCollection').removeClass('hidden');
                            },
                            href: '#velaNotifiCollection',
                            helpers:  {
                                overlay : true
                            },
                            afterClose : function(){
                                $('#velaNotifiCollection').addClass('hidden');
                                $.cookie('velaNotifiCollectioin', 'closed', {expires:dateCookie, path:'/'});
                            }
                        }
                    });
                }
                else if ( document.body.classList.contains('template-blog') && ($("#velaNotifiBlog").length > 0) && ($.cookie('velaNotifiBlog') != 'closed')) {
                    $.fancybox.open({
                        src  : '#velaNotifiBlog',
                        opts : {
                            padding: 0,
                            beforeLoad: function(){
                                $('#velaNotifiBlog').removeClass('hidden');
                            },
                            href: '#velaNotifiBlog',
                            helpers:  {
                                overlay : true
                            },
                            afterClose : function(){
                                $('#velaNotifiBlog').addClass('hidden');
                                $.cookie('velaNotifiBlog', 'closed', {expires:dateCookie, path:'/'});
                            }
                        }
                    });
                }
                else if (document.body.classList.contains('template-product') && ($("#velaNotifiProduct").length > 0) && ($.cookie('velaNotifiProduct') != 'closed')) {
                    $.fancybox.open({
                        src  : '#velaNotifiProduct',
                        opts : {
                            padding: 0,
                            beforeLoad: function(){
                                $('#velaNotifiProduct').removeClass('hidden');
                            },
                            href: '#velaNotifiProduct',
                            helpers:  {
                                overlay : true
                            },
                            afterClose : function(){
                                $('#velaNotifiProduct').addClass('hidden');
                                $.cookie('velaNotifiProduct', 'closed', {expires:dateCookie, path:'/'});
                            }
                        }
                    });
                }
                else if ( document.body.classList.contains('template-page') && ($("#velaNotifiPage").length > 0) && ($.cookie('velaNotifiPage') != 'closed')) {
                    $.fancybox.open({
                        src  : '#velaNotifiPage',
                        opts : {
                            padding: 0,
                            beforeLoad: function(){
                                $('#velaNotifiPage').removeClass('hidden');
                            },
                            href: '#velaNotifiPage',
                            helpers:  {
                                overlay : true
                            },
                            afterClose : function(){
                                $('#velaNotifiPage').addClass('hidden');
                                $.cookie('velaNotifiPage', 'closed', {expires:dateCookie, path:'/'});
                            }
                        }
                    });
                }
                else if (($("#velaNotifi").length > 0) && ($.cookie('velaNotifi') != 'closed')){
                    $.fancybox.open({
                        src  : '#velaNotifi',
                        opts : {
                            padding: 0,
                            beforeLoad: function(){
                                $('#velaNotifi').removeClass('hidden');
                            },
                            href: '#velaNotifi',
                            helpers:  {
                                overlay : true
                            },
                            afterClose : function(){
                                $('#velaNotifi').addClass('hidden');
                                $.cookie('velaNotifi', 'closed', {expires:dateCookie, path:'/'});
                            }
                        }
                    });
                }
                
            }, 0);
        });
    </script>



    <script id="CartTemplate" type="text/template">
    
        <form action="/cart" method="post" novalidate class="cart ajaxcart">
            <div class="ajaxCartInner">
                {{#items}}
                <div class="ajaxCartProduct">
                    <div class="drawerProduct ajaxCartRow" data-line="{{line}}">
                        <div class="drawerProductImage">
                            <a href="{{url}}"><img class="img-responsive" src="{{img}}" alt="" /></a>
                        </div>
                        <div class="drawerProductContent">
                            <div class="drawerProductTitle">
                                <a href="{{url}}">{{name}}</a>
                                {{#if variation}}
                                    <span>{{variation}}</span>
                                {{/if}}
                                {{#properties}}
                                    {{#each this}}
                                        {{#if this}}
                                            <span>{{@key}}: {{this}}</span>
                                        {{/if}}
                                    {{/each}}
                                {{/properties}}

                                

                            </div>
                            <div class="drawerProductPrice">
                                <div class="priceProduct">
                                    {{{price}}}
                                </div>
                            </div>
                            <div class="drawerProductQty">
                                <div class="velaQty">
                                    <button type="button" class="qtyAdjust velaQtyButton velaQtyMinus" data-id="{{id}}" data-qty="{{itemMinus}}" data-line="{{line}}">
                                        <span class="txtFallback">&minus;</span>
                                    </button>
                                    <input type="text" name="updates[]" class="qtyNum velaQtyText" value="{{itemQty}}" min="0" data-id="{{id}}" data-line="{{line}}"  pattern="[0-9]*" />
                                    <button type="button" class="qtyAdjust velaQtyButton velaQtyPlus" data-id="{{id}}" data-line="{{line}}" data-qty="{{itemAdd}}">
                                        <span class="txtFallback">+</span>
                                    </button>
                                </div>
                            </div>
                            <div class="drawerProductDelete">
                                <div class="cartRemoveBox">
                                    <a href="#" class="cartRemove btnClose" onclick="return false;" data-line="{{ line }}">
                                        <span>Remove</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{/items}}
                
    
                
    
                    <div class="ajaxCartNote">
                        <div class="velaCartNoteButton">
                            <a class="btnCartNote collapsed" href="#velaCartNote" data-toggle="collapse">
                                <i class="fa fa-times"></i>
                                add order note
                            </a>
                        </div>
                        <div id="velaCartNote" class="velaCartNoteGroup collapse">
                            <label for="CartSpecialInstructions">Special instructions for seller</label>
                            <textarea name="note" class="form-control" id="CartSpecialInstructions" rows="4">{{ note }}</textarea>
                        </div>
                    </div>
    
                
    
                <div class="drawerCartFooter">
                    <div class="drawerAjaxFooter">
                        <div class="drawerSubtotal">
                            <span class="cartSubtotalHeading">Subtotal</span>
                            <span class="cartSubtotal">{{{totalPrice}}}</span>
                        </div>
                        <p class="drawerShipping">Shipping, taxes, and discounts will be calculated at checkout.</p>
                        <div class="drawerButton">
                            <div class="drawerButtonBox">
                                <a class="btn btnVelaCart btnViewCart" href="/cart">
                                    View Cart
                                </a>
                            </div>
                            <div class="drawerButtonBox">
                                <button type="submit" class="btn btnVelaCart btnCheckout" name="checkout">
                                    Check Out
                                </button>
                            </div>
    
                            
    
                        </div>
                    </div>
                </div>
            </div>
        </form>
    
</script>


<script id="headerCartTemplate" type="text/template">
    <form action="/cart" method="post" novalidate class="cart ajaxcart">
    <div class="headerCartInner">
        <div class="headerCartScroll">

        {{#items}}
            <div class="ajaxCartProduct">
                <div class="ajaxCartRow rowFlex" data-line="{{line}}">
                    <div class="headerCartImage">
                        <a href="{{url}}"><img class="img-responsive" src="{{img}}" alt="" /></a>
                    </div>
                    <div class="headerCartContent">
                        <div class="headerCartInfo">
                            <a href="{{url}}" class="headerCartProductName">{{name}}</a>
                            {{#if variation}}
                                <div class="headerCartProductMeta">{{variation}}</div>
                            {{/if}}
                            {{#properties}}
                                {{#each this}}
                                    {{#if this}}
                                        <div class="headerCartProductMeta">{{@key}}: {{this}}</div>
                                    {{/if}}
                                {{/each}}
                            {{/properties}}
        
                            
        
                            <div class="headerCartPrice">
                                {{{price}}} <span class="d-block">x {{itemQty}}</span>
                            </div>
                        </div>
                        <div class="headerCartRemoveBox">
                            <a href="#" class="cartRemove" onclick="return false;" data-line="{{ line }}">
                                <i class="btnClose"></i> <span>Remove</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        {{/items}}
        </div>
        <div class="headerCartTotal">
            <span class="headerCartTotalTitle">Subtotal</span>
            <span class="headerCartTotalNum">{{{totalPrice}}}</span>
        </div>
        <div class="headerCartButton d-flex">
            <div class="headerCartButtonBox mr10">
                <a class="btn btnVelaCart btnViewCart" href="/cart">
        
                    View Cart
        
                </a>
            </div>
            <div class="headerCartButtonBox">
                <button type="submit" class="btn btnVelaCart btnCheckout" name="checkout">
        
                    Check Out
        
                </button>
            </div>
        </div>

    </div>
    </form>
</script>
<script id="velaAjaxQty" type="text/template">
    
        <div class="velaQty">
            <button type="button" class="qtyAdjust velaQtyButton velaQtyMinus" data-id="{{id}}" data-qty="{{itemMinus}}">
                <span class="txtFallback">&minus;</span>
            </button>
            <input type="text" class="qtyNum velaQtyText" value="{{itemQty}}" min="0" data-id="{{id}}" aria-label="quantity" pattern="[0-9]*">
            <button type="button" class="qtyAdjust velaQtyButton velaQtyPlus" data-id="{{id}}" data-qty="{{itemAdd}}">
                <span class="txtFallback">+</span>
            </button>
        </div>
    
</script>

<script id="velaJsQty" type="text/template">
    
        <div class="velaQty">
            <button type="button" class="velaQtyAdjust velaQtyButton velaQtyMinus" data-id="{{id}}" data-qty="{{itemMinus}}">
                <span class="txtFallback">&minus;</span>
            </button>
            <input type="text" class="velaQtyNum velaQtyText" value="{{itemQty}}" min="1" data-id="{{id}}" aria-label="quantity" pattern="[0-9]*" name="{{inputName}}" id="{{inputId}}" />
            <button type="button" class="velaQtyAdjust velaQtyButton velaQtyPlus" data-id="{{id}}" data-qty="{{itemAdd}}">
                <span class="txtFallback">+</span>
            </button>
        </div>
    
</script>

<div id="loading" style="display:none;"></div>
<div id="velaQuickView" style="display:none;">
        <div class="quickviewOverlay"></div>
        <div class="jsQuickview"></div>
        <div id="quickviewModal" class="quickviewProduct" style="display:none;">
            <a title="Close" class="quickviewClose btnClose" href="javascript:void(0);"></a>
            <div class="proBoxPrimary row">
                <div class="proBoxImage col-xs-12 col-sm-12 col-md-5">
                    <div class="proFeaturedImage">
                        <a class="proImage" title="" href="#">
                            <img class="img-responsive proImageQuickview" src="//cdn.shopify.com/s/files/1/0276/4616/5110/t/5/assets/loading.gif?v=4737358046173361859" alt="Quickview">
                            <span class="loadingImage"></span>
                        </a>
                    </div>
                    <div class="proThumbnails proThumbnailsQuickview clearfix">
                        <div class="owl-thumblist">
                            <div class="owl-carousel">

                            </div>
                        </div>
                    </div>
                </div>
                <div class="proBoxInfo col-xs-12 col-sm-12 col-md-7">
                    <h3 class="quickviewName mb20">&nbsp;</h3>
                    <div class="proShortDescription rte"></div>
                    
                    <form action="/cart/add" method="post" enctype="multipart/form-data" class="formQuickview form-ajaxtocart">                       
                        <div class="proVariantsQuickview"><select name="id" style="display:none"></select></div>
                        <div class="proPrice clearfix">
                            <span class="priceProduct priceCompare"></span>
                            <span class="priceProduct pricePrimary"></span>
                            
                        </div>
                        <div class="velaGroup d-flex flexAlignEnd mb20">
                            <div class="proQuantity">
                                <!-- <label for="Quantity" class="qtySelector">Quantity</label> -->
                                
    
        <div class="velaQty">
            <button type="button" class="velaQtyAdjust velaQtyButton velaQtyMinus" data-id="" data-qty="0">
                <span class="txtFallback">−</span>
            </button>
            <input type="text" class="velaQtyNum velaQtyText" value="1" min="1" data-id="" aria-label="quantity" pattern="[0-9]*" name="quantity" id="Quantity">
            <button type="button" class="velaQtyAdjust velaQtyButton velaQtyPlus" data-id="" data-qty="11">
                <span class="txtFallback">+</span>
            </button>
        </div>
    

                            </div>
                            <div class="proButton">
                                <button type="submit" name="add" class="btn btnAddToCart">
                                    <span>Add to Cart</span>
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="proAttr quickviewAvailability"></div>
                    <div class="proAttr quickViewVendor"></div>
                    <div class="proAttr quickViewType"></div>
                    <div class="proAttr quickViewSKU"></div>
                   
                </div>
            </div>
        </div>    
    </div>

    <div id="goToTop" class="hidden-xs hidden-sm" style="display: block;"><span class="fa fa-angle-up"></span></div>


        <script src="../js/option_selection.js" type="text/javascript"></script>
        <script src="../js/api.jquery.js" type="text/javascript"></script>
        <script src="../js/currencies.js" type="text/javascript"></script>
        <script src="../js/vendor.js" type="text/javascript"></script>
        <script src="../js/vela_ajaxcart.js" type="text/javascript"></script>
        <script src="../js/lazysizes.min.js" async="async"></script>
        <script src="../js/vela.js" type="text/javascript"></script>
        <script src="../js/jquery.cookie.js" type="text/javascript"></script>
        <script type="text/javascript">
    if (window.currencies) {
        Currency.format = "money_format";
        var shopCurrency = window.currency;
        Currency.moneyFormats[shopCurrency].money_with_currency_format = window.shop_money_with_currency_format;
        Currency.moneyFormats[shopCurrency].money_format = window.shop_money_format;
        var defaultCurrency = 'USD';
        var cookieCurrency = Currency.cookie.read();
        var velaCurrencies = $('[name=currencies]'),
            velaCurrencyItem = $('.jsvela-currency__item'),
            velaCurrencyCurrent = $('.jsvela-currency__current');
        $('span.money span.money').each(function() {
            $(this).parents('span.money').removeClass('money');
        });
        $('span.money').each(function() {
            $(this).attr('data-currency-' + window.currency, $(this).html());
        });
        if (cookieCurrency == null) {
            if (shopCurrency !== defaultCurrency) {
                Currency.convertAll(shopCurrency, defaultCurrency);
            }
            else {
                Currency.currentCurrency = defaultCurrency;
            }
        }
        else if ($('[name=currencies]').size() && $('[name=currencies] .jsvela-currency__item[data-value=' + cookieCurrency + ']').size() === 0) {
            Currency.currentCurrency = shopCurrency;
            Currency.cookie.write(shopCurrency);
        }
        else if (cookieCurrency === shopCurrency) {
            Currency.currentCurrency = shopCurrency;
        }
        else {
            Currency.currentCurrency = cookieCurrency;
            Currency.convertAll(shopCurrency, cookieCurrency);
            velaCurrencies.data('value', cookieCurrency);
            velaCurrencyItem.removeClass('active');
            velaCurrencyItem.each(function() {
                if ($(this).data('value') === cookieCurrency)
                    $(this).addClass('active');
            });

        }
        $('body').on('click', '.jsvela-currency__item', function() {
            var newCurrency = $(this).data('value');
            velaCurrencies.data('value', newCurrency);
            velaCurrencyItem.removeClass('active');
            $(this).addClass('active');
            Currency.convertAll(Currency.currentCurrency, newCurrency);
            velaCurrencyCurrent.text(Currency.currentCurrency);
            return false;
        });
        var original_selectCallback = window.selectCallback;
        var selectCallback = function(variant, selector) {
            original_selectCallback(variant, selector);
            Currency.convertAll(shopCurrency, $('[name=currencies]').data('value'));
            velaCurrencyCurrent.text(Currency.currentCurrency);
        };
        $('body').on('ajaxCart.afterCartLoad', function(cart) {
            Currency.convertAll(shopCurrency, $('[name=currencies]').data('value'));
            velaCurrencyCurrent.text(Currency.currentCurrency);  
        });
        velaCurrencyCurrent.text(Currency.currentCurrency);
    }
</script>