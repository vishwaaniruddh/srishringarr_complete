<? include('config.php') ; 

echo cartcount();

?>

