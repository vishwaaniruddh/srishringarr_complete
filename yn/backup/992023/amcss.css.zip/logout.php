<? session_start();


session_destroy();

?>
Please Wait ... 

<script>
        window.location.href="index.php";

</script>